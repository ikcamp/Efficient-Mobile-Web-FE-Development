export default {
  // httpHost: 'localhost',
  // httpPort: 4412,
  // httpsHost: 'localhost',
  // httpsPort: 4413,
  // httpServer: 'http://localhost:4412',
  // httpsServer: 'https://localhost:4413',
  // httpHost: '192.168.37.118',
  // httpPort: 5801
  // httpsHost: '192.168.37.118',
  // httpsPort: 5801,

  httpServer: 'http://192.168.37.118:5800',
  httpsServer: 'https://192.168.37.118:5801'
}


